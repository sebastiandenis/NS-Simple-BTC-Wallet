module.exports = require("nativescript-dev-sass/lib/after-prepare.js");
