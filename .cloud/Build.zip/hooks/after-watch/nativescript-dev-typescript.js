module.exports = require("nativescript-dev-typescript/lib/after-watch.js");
