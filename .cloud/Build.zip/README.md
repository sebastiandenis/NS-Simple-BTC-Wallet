## Simple Bitcoin Wallet
* The fastest way to launch: download -> connect your device -> open with NativeScript SideKick -> use Cloud build

